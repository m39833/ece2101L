# PySpice stubs

Manually curated PEP 561 stubs for the public API of PySpice.  The stubs target
the PySpice 1.5 API and the compatible public surface on the repository's
`master` branch.

Release 1.5.0.8 preserves NumPy dtypes when converting waveforms with
`numpy.asarray`. AC and pole-zero waveforms carry `numpy.complex128`, while
real-valued analyses carry `numpy.float64`, so `.item()` no longer becomes
`Any`. It also includes the controlled-source builders from 1.5.0.7 (`VCCS`, `VCVS`,
`CCCS`, and `CCVS`), their full class-name forms, and the corresponding `VCS`
and `CCS` switch aliases. Their gain, transconductance, transresistance, and
controlling-source parameters now have concrete types. It also includes the
`UnitValue` arithmetic improvements from 1.5.0.6 and all earlier refinements.

Install PySpice and this project in the same environment:

```bash
python -m pip install PySpice
python -m pip install ./pyspice-stubs
```

The package is intentionally stub-only.  Dynamic element descriptors and
simulator-specific extension points retain `Any` where PySpice determines a
type at runtime.

`Circuit.X(...)` intentionally retains open-ended keyword arguments because
subcircuit parameters are user-defined.
