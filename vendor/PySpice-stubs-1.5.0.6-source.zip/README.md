# PySpice stubs

Manually curated PEP 561 stubs for the public API of PySpice.  The stubs target
the PySpice 1.5 API and the compatible public surface on the repository's
`master` branch.

Release 1.5.0.6 adds concrete `UnitValue` arithmetic return types, including
scalar promotion and reflected multiplication and division. It also includes
the model-type-specific keyword schemas from 1.5.0.5, typed simulator methods
from 1.5.0.4, scalar-aware waveforms from 1.5.0.3, and the PEP 692 element
keyword schemas from 1.5.0.2.

Install PySpice and this project in the same environment:

```bash
python -m pip install PySpice
python -m pip install ./pyspice-stubs
```

The package is intentionally stub-only.  Dynamic element descriptors and
simulator-specific extension points retain `Any` where PySpice determines a
type at runtime.

`Circuit.X(...)` intentionally retains open-ended keyword arguments because
subcircuit parameters are user-defined.
