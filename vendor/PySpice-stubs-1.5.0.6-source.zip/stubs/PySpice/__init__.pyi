from typing import Final

__version__: Final[str]
__author__: Final[str]
__email__: Final[str]
