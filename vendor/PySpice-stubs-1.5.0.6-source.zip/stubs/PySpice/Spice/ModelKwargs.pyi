from typing_extensions import TypedDict
from .ElementKwargs import SpiceValue

class SwitchModelKwargs(TypedDict, total=False):
    ron: SpiceValue
    roff: SpiceValue
    vt: SpiceValue
    vh: SpiceValue

class CurrentSwitchModelKwargs(TypedDict, total=False):
    ron: SpiceValue
    roff: SpiceValue
    it: SpiceValue
    ih: SpiceValue

class ResistorModelKwargs(TypedDict, total=False):
    tnom: SpiceValue
    tc1: SpiceValue
    tc2: SpiceValue
    tce: SpiceValue
    rsh: SpiceValue
    defw: SpiceValue
    narrow: SpiceValue
    short: SpiceValue

class CapacitorModelKwargs(TypedDict, total=False):
    tnom: SpiceValue
    cj: SpiceValue
    cjsw: SpiceValue
    defw: SpiceValue
    narrow: SpiceValue

class DiodeModelKwargs(TypedDict, total=False):
    level: int
    tnom: SpiceValue
    is_: SpiceValue
    rs: SpiceValue
    n: SpiceValue
    tt: SpiceValue
    cjo: SpiceValue
    vj: SpiceValue
    m: SpiceValue
    eg: SpiceValue
    xti: SpiceValue
    kf: SpiceValue
    af: SpiceValue
    fc: SpiceValue
    bv: SpiceValue
    ibv: SpiceValue

class BjtModelKwargs(TypedDict, total=False):
    level: int
    tnom: SpiceValue
    is_: SpiceValue
    bf: SpiceValue
    nf: SpiceValue
    vaf: SpiceValue
    ikf: SpiceValue
    ise: SpiceValue
    ne: SpiceValue
    br: SpiceValue
    nr: SpiceValue
    var: SpiceValue
    ikr: SpiceValue
    isc: SpiceValue
    nc: SpiceValue
    rb: SpiceValue
    irb: SpiceValue
    rbm: SpiceValue
    re: SpiceValue
    rc: SpiceValue
    cje: SpiceValue
    vje: SpiceValue
    mje: SpiceValue
    tf: SpiceValue
    xtf: SpiceValue
    vtf: SpiceValue
    itf: SpiceValue
    ptf: SpiceValue
    cjc: SpiceValue
    vjc: SpiceValue
    mjc: SpiceValue
    xcjc: SpiceValue
    tr: SpiceValue
    cjs: SpiceValue
    vjs: SpiceValue
    mjs: SpiceValue
    xtb: SpiceValue
    eg: SpiceValue
    xti: SpiceValue
    kf: SpiceValue
    af: SpiceValue
    fc: SpiceValue

class JfetModelKwargs(TypedDict, total=False):
    level: int
    tnom: SpiceValue
    vto: SpiceValue
    beta: SpiceValue
    lambda_: SpiceValue
    rd: SpiceValue
    rs: SpiceValue
    cgs: SpiceValue
    cgd: SpiceValue
    pb: SpiceValue
    is_: SpiceValue
    b: SpiceValue
    kf: SpiceValue
    af: SpiceValue
    fc: SpiceValue

class MosfetModelKwargs(TypedDict, total=False):
    level: int
    version: SpiceValue
    tnom: SpiceValue
    vto: SpiceValue
    vt0: SpiceValue
    kp: SpiceValue
    gamma: SpiceValue
    phi: SpiceValue
    lambda_: SpiceValue
    rd: SpiceValue
    rs: SpiceValue
    cbd: SpiceValue
    cbs: SpiceValue
    is_: SpiceValue
    pb: SpiceValue
    cgso: SpiceValue
    cgdo: SpiceValue
    cgbo: SpiceValue
    rsh: SpiceValue
    cj: SpiceValue
    mj: SpiceValue
    cjsw: SpiceValue
    mjsw: SpiceValue
    js: SpiceValue
    tox: SpiceValue
    nsub: SpiceValue
    nss: SpiceValue
    nfs: SpiceValue
    tpg: SpiceValue
    xj: SpiceValue
    ld: SpiceValue
    uo: SpiceValue
    u0: SpiceValue
    ucrit: SpiceValue
    uexp: SpiceValue
    utra: SpiceValue
    vmax: SpiceValue
    neff: SpiceValue
    kf: SpiceValue
    af: SpiceValue

class MesfetModelKwargs(TypedDict, total=False):
    level: int
    tnom: SpiceValue
    vto: SpiceValue
    beta: SpiceValue
    b: SpiceValue
    lambda_: SpiceValue
    alpha: SpiceValue
    rd: SpiceValue
    rs: SpiceValue
    cgs: SpiceValue
    cgd: SpiceValue
    pb: SpiceValue
    fc: SpiceValue
    is_: SpiceValue
    kf: SpiceValue
    af: SpiceValue

class UrcModelKwargs(TypedDict, total=False):
    k: SpiceValue
    fmax: SpiceValue
    rperl: SpiceValue
    cperl: SpiceValue
    isperl: SpiceValue
    rsperl: SpiceValue

class LtraModelKwargs(TypedDict, total=False):
    r: SpiceValue
    l: SpiceValue
    g: SpiceValue
    c: SpiceValue
    length: SpiceValue
    len: SpiceValue
    rel: SpiceValue
    abs: SpiceValue
    frequency: SpiceValue
    freq: SpiceValue
    nosteplimit: bool
    nocontrol: bool
    lininterp: bool
    mixedinterp: bool
    compactrel: SpiceValue
    compactabs: SpiceValue
    truncnr: bool
    truncdontcut: bool
    steplimit: bool
