from os import PathLike
from typing import Optional, Union
from PySpice.Spice.Netlist import Circuit
from PySpice.Spice.Simulation import CircuitSimulator
from PySpice.Spice.SimulationTypes import TemperatureValue

class XyceCircuitSimulator(CircuitSimulator):
    def __init__(self, circuit: Circuit, *, temperature: TemperatureValue = ..., nominal_temperature: TemperatureValue = ..., xyce_command: Optional[Union[str, PathLike[str]]] = ..., parallel: bool = ...) -> None: ...
