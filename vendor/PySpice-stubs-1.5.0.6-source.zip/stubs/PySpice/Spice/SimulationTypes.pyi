from os import PathLike
from typing import Any, Literal, Union
from typing_extensions import TypedDict
from PySpice.Unit.Unit import UnitValue
from .NgSpice.Shared import NgSpiceShared

SimulationValue = Union[int, float, UnitValue[Any]]
TimeValue = SimulationValue
FrequencyValue = SimulationValue
TemperatureValue = SimulationValue
SimulatorName = Literal[
    "ngspice-subprocess",
    "ngspice-shared",
    "xyce-serial",
    "xyce-parallel",
]
Variation = Literal["dec", "oct", "lin"]
TransferFunctionType = Literal["cur", "vol"]
PoleZeroType = Literal["pol", "zer", "pz"]
AnalysisType = Literal[
    "ac", "dc", "op", "tran", "tf", "noise",
    "AC", "DC", "OP", "TRAN", "TF", "NOISE",
]

class SimulatorKwargs(TypedDict, total=False):
    pipe: bool
    spice_command: Union[str, PathLike[str]]
    ngspice_shared: NgSpiceShared
    xyce_command: Union[str, PathLike[str]]
    parallel: bool
