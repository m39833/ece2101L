from collections.abc import Sequence
from typing import Any, Union
from typing_extensions import TypedDict
from ..Unit.Unit import UnitValue, UnitValues

# PySpice accepts Python scalars, SPICE expressions, and unit-aware values for
# most numeric parameters.  Keeping the leaf value broad preserves that API
# while the TypedDicts provide the useful part: keyword-name checking and
# completion.
SpiceValue = Union[str, int, float, complex, UnitValue[Any], UnitValues]
InitialCondition = Union[SpiceValue, Sequence[SpiceValue]]

class ElementKwargs(TypedDict, total=False):
    raw_spice: str

class TemperatureKwargs(ElementKwargs, total=False):
    temperature: SpiceValue
    temp: SpiceValue
    device_temperature: SpiceValue
    dtemp: SpiceValue

class ResistorKwargs(TemperatureKwargs, total=False):
    model: str
    ac: SpiceValue
    multiplier: SpiceValue
    m: SpiceValue
    scale: SpiceValue
    noisy: bool

class CapacitorKwargs(TemperatureKwargs, total=False):
    model: str
    multiplier: SpiceValue
    m: SpiceValue
    scale: SpiceValue
    initial_condition: InitialCondition
    ic: InitialCondition

class InductorKwargs(TemperatureKwargs, total=False):
    model: str
    nt: SpiceValue
    multiplier: SpiceValue
    m: SpiceValue
    scale: SpiceValue
    initial_condition: InitialCondition
    ic: InitialCondition

class CoupledInductorKwargs(ElementKwargs, total=False):
    pass

class DiodeKwargs(TemperatureKwargs, total=False):
    area: SpiceValue
    multiplier: SpiceValue
    m: SpiceValue
    perimeter: SpiceValue
    pj: SpiceValue
    off: bool
    initial_condition: InitialCondition
    ic: InitialCondition

class BjtKwargs(TemperatureKwargs, total=False):
    area: SpiceValue
    areac: SpiceValue
    areab: SpiceValue
    multiplier: SpiceValue
    m: SpiceValue
    off: bool
    initial_condition: InitialCondition
    ic: InitialCondition

class JfetKwargs(TemperatureKwargs, total=False):
    area: SpiceValue
    multiplier: SpiceValue
    m: SpiceValue
    off: bool
    initial_condition: InitialCondition
    ic: InitialCondition

class MosfetKwargs(TemperatureKwargs, total=False):
    multiplier: SpiceValue
    m: SpiceValue
    length: SpiceValue
    l: SpiceValue
    width: SpiceValue
    w: SpiceValue
    nfin: SpiceValue
    drain_area: SpiceValue
    ad: SpiceValue
    source_area: SpiceValue
    as_: SpiceValue
    drain_perimeter: SpiceValue
    pd: SpiceValue
    source_perimeter: SpiceValue
    ps: SpiceValue
    drain_number_square: SpiceValue
    nrd: SpiceValue
    source_number_square: SpiceValue
    nrs: SpiceValue
    off: bool
    initial_condition: InitialCondition
    ic: InitialCondition

class SourceKwargs(ElementKwargs, total=False):
    dc_value: SpiceValue

class BehavioralSourceKwargs(TemperatureKwargs, total=False):
    current_expression: SpiceValue
    i: SpiceValue
    voltage_expression: SpiceValue
    v: SpiceValue
    tc1: SpiceValue
    tc2: SpiceValue

class GainKwargs(ElementKwargs, total=False):
    multiplier: SpiceValue
    m: SpiceValue

class SwitchKwargs(ElementKwargs, total=False):
    initial_state: Union[str, bool]

class TransmissionLineKwargs(ElementKwargs, total=False):
    Z0: SpiceValue
    time_delay: SpiceValue
    TD: SpiceValue
    frequency: SpiceValue
    F: SpiceValue
    normalized_length: SpiceValue
    NL: SpiceValue
    initial_condition: InitialCondition
    IC: InitialCondition

class SinusoidalSourceKwargs(SourceKwargs, total=False):
    dc_offset: SpiceValue
    ac_magnitude: SpiceValue
    offset: SpiceValue
    amplitude: SpiceValue
    frequency: SpiceValue
    delay: SpiceValue
    damping_factor: SpiceValue

class PulseSourceKwargs(SourceKwargs, total=False):
    initial_value: SpiceValue
    pulsed_value: SpiceValue
    pulse_width: SpiceValue
    period: SpiceValue
    delay_time: SpiceValue
    rise_time: SpiceValue
    fall_time: SpiceValue
    phase: SpiceValue
    dc_offset: SpiceValue

class ExponentialSourceKwargs(SourceKwargs, total=False):
    initial_value: SpiceValue
    pulsed_value: SpiceValue
    rise_delay_time: SpiceValue
    rise_time_constant: SpiceValue
    fall_delay_time: SpiceValue
    fall_time_constant: SpiceValue

class PieceWiseLinearSourceKwargs(SourceKwargs, total=False):
    repeat_time: SpiceValue
    delay_time: SpiceValue
    dc: SpiceValue

class RandomSourceKwargs(SourceKwargs, total=False):
    random_type: Union[str, int]
    duration: SpiceValue
    time_delay: SpiceValue
    parameter1: SpiceValue
    parameter2: SpiceValue

class SingleFrequencyFMSourceKwargs(SourceKwargs, total=False):
    offset: SpiceValue
    amplitude: SpiceValue
    carrier_frequency: SpiceValue
    modulation_index: SpiceValue
    signal_frequency: SpiceValue

class AmplitudeModulatedSourceKwargs(SourceKwargs, total=False):
    offset: SpiceValue
    amplitude: SpiceValue
    modulating_frequency: SpiceValue
    carrier_frequency: SpiceValue
    signal_delay: SpiceValue
