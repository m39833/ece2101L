from os import PathLike
from typing import Optional, Union
from PySpice.Spice.Netlist import Circuit
from PySpice.Spice.Simulation import CircuitSimulator
from PySpice.Spice.SimulationTypes import TemperatureValue
from .Shared import NgSpiceShared

class NgSpiceCircuitSimulator(CircuitSimulator):
    def __init__(self, circuit: Circuit, *, temperature: TemperatureValue = ..., nominal_temperature: TemperatureValue = ..., pipe: bool = ...) -> None: ...
class NgSpiceSubprocessCircuitSimulator(NgSpiceCircuitSimulator):
    def __init__(self, circuit: Circuit, *, temperature: TemperatureValue = ..., nominal_temperature: TemperatureValue = ..., spice_command: Optional[Union[str, PathLike[str]]] = ...) -> None: ...
class NgSpiceSharedCircuitSimulator(NgSpiceCircuitSimulator):
    def __init__(self, circuit: Circuit, *, temperature: TemperatureValue = ..., nominal_temperature: TemperatureValue = ..., ngspice_shared: Optional[NgSpiceShared] = ...) -> None: ...
    @property
    def ngspice(self) -> NgSpiceShared: ...
