from typing import Any, ClassVar, Optional
from typing_extensions import Unpack
from .ElementKwargs import (
    BehavioralSourceKwargs, BjtKwargs, CapacitorKwargs,
    CoupledInductorKwargs, DiodeKwargs, ElementKwargs, GainKwargs,
    InductorKwargs, JfetKwargs, MosfetKwargs, ResistorKwargs,
    SourceKwargs, SwitchKwargs, TransmissionLineKwargs,
)
from .Netlist import AnyPinElement, Element, FixedPinElement, Name, Netlist, NodeLike, Pin

class DipoleElement(FixedPinElement):
    @property
    def plus(self) -> Pin: ...
    @property
    def minus(self) -> Pin: ...

class Resistor(DipoleElement):
    def __init__(self, netlist: Netlist, name: Name, node_plus: NodeLike, node_minus: NodeLike, resistance: Any, **kwargs: Unpack[ResistorKwargs]) -> None: ...
    resistance: Any
    model: Optional[str]
    ac: Any
    multiplier: Any
    scale: Any
    temperature: Any
    device_temperature: Any
    noise: Any
class SemiconductorResistor(Resistor): ...
class BehavioralResistor(DipoleElement):
    resistance_expression: Any
class Capacitor(DipoleElement):
    def __init__(self, netlist: Netlist, name: Name, node_plus: NodeLike, node_minus: NodeLike, capacitance: Any, **kwargs: Unpack[CapacitorKwargs]) -> None: ...
    capacitance: Any
    model: Optional[str]
    multiplier: Any
    scale: Any
    temperature: Any
    device_temperature: Any
    initial_condition: Any
class SemiconductorCapacitor(Capacitor): ...
class BehavioralCapacitor(DipoleElement):
    capacitance_expression: Any
class Inductor(DipoleElement):
    def __init__(self, netlist: Netlist, name: Name, node_plus: NodeLike, node_minus: NodeLike, inductance: Any, **kwargs: Unpack[InductorKwargs]) -> None: ...
    inductance: Any
    model: Optional[str]
    multiplier: Any
    scale: Any
    temperature: Any
    device_temperature: Any
    initial_condition: Any
class BehavioralInductor(DipoleElement):
    inductance_expression: Any
class CoupledInductor(AnyPinElement):
    def __init__(self, netlist: Netlist, name: Name, inductor1: Any, inductor2: Any, coupling_factor: Any, **kwargs: Unpack[CoupledInductorKwargs]) -> None: ...
    inductor1: Any
    inductor2: Any
    coupling_factor: Any
class Diode(FixedPinElement):
    def __init__(self, netlist: Netlist, name: Name, anode: NodeLike, cathode: NodeLike, model: str, **kwargs: Unpack[DiodeKwargs]) -> None: ...
    model: str
    area: Any
    multiplier: Any
    off: bool
    temperature: Any
    device_temperature: Any
    @property
    def anode(self) -> Pin: ...
    @property
    def cathode(self) -> Pin: ...
class BipolarJunctionTransistor(FixedPinElement):
    def __init__(self, netlist: Netlist, name: Name, collector: NodeLike, base: NodeLike, emitter: NodeLike, model: str, substrate: Optional[NodeLike] = ..., **kwargs: Unpack[BjtKwargs]) -> None: ...
    model: str
    area: Any
    multiplier: Any
    off: bool
    @property
    def collector(self) -> Pin: ...
    @property
    def base(self) -> Pin: ...
    @property
    def emitter(self) -> Pin: ...
    @property
    def substrate(self) -> Pin: ...
class JunctionFieldEffectTransistor(FixedPinElement):
    def __init__(self, netlist: Netlist, name: Name, drain: NodeLike, gate: NodeLike, source: NodeLike, model: str, **kwargs: Unpack[JfetKwargs]) -> None: ...
    model: str
    @property
    def drain(self) -> Pin: ...
    @property
    def gate(self) -> Pin: ...
    @property
    def source(self) -> Pin: ...
class Mosfet(FixedPinElement):
    def __init__(self, netlist: Netlist, name: Name, drain: NodeLike, gate: NodeLike, source: NodeLike, bulk: NodeLike, model: str, **kwargs: Unpack[MosfetKwargs]) -> None: ...
    model: str
    multiplier: Any
    length: Any
    width: Any
    @property
    def drain(self) -> Pin: ...
    @property
    def gate(self) -> Pin: ...
    @property
    def source(self) -> Pin: ...
    @property
    def bulk(self) -> Pin: ...
class Mesfet(JunctionFieldEffectTransistor): ...
class CurrentSource(DipoleElement):
    def __init__(self, netlist: Netlist, name: Name, node_plus: NodeLike, node_minus: NodeLike, value: Any = ..., **kwargs: Unpack[SourceKwargs]) -> None: ...
    dc_value: Any
class VoltageSource(DipoleElement):
    def __init__(self, netlist: Netlist, name: Name, node_plus: NodeLike, node_minus: NodeLike, value: Any = ..., **kwargs: Unpack[SourceKwargs]) -> None: ...
    dc_value: Any
class BehavioralSource(DipoleElement):
    def __init__(self, netlist: Netlist, name: Name, node_plus: NodeLike, node_minus: NodeLike, **kwargs: Unpack[BehavioralSourceKwargs]) -> None: ...
    current_expression: Any
    voltage_expression: Any
class VoltageControlledVoltageSource(DipoleElement):
    def __init__(self, netlist: Netlist, name: Name, output_plus: NodeLike, output_minus: NodeLike, input_plus: NodeLike, input_minus: NodeLike, voltage_gain: Any, **kwargs: Unpack[ElementKwargs]) -> None: ...
    voltage_gain: Any
class VoltageControlledCurrentSource(DipoleElement):
    def __init__(self, netlist: Netlist, name: Name, output_plus: NodeLike, output_minus: NodeLike, input_plus: NodeLike, input_minus: NodeLike, transconductance: Any, **kwargs: Unpack[GainKwargs]) -> None: ...
    transconductance: Any
class CurrentControlledCurrentSource(DipoleElement):
    def __init__(self, netlist: Netlist, name: Name, node_plus: NodeLike, node_minus: NodeLike, source: Any, current_gain: Any, **kwargs: Unpack[GainKwargs]) -> None: ...
    source: Any
    current_gain: Any
class CurrentControlledVoltageSource(DipoleElement):
    def __init__(self, netlist: Netlist, name: Name, node_plus: NodeLike, node_minus: NodeLike, source: Any, transresistance: Any, **kwargs: Unpack[ElementKwargs]) -> None: ...
    source: Any
    transresistance: Any
class NonLinearVoltageSource(DipoleElement): ...
class NonLinearCurrentSource(DipoleElement): ...
class VoltageControlledSwitch(DipoleElement):
    def __init__(self, netlist: Netlist, name: Name, node_plus: NodeLike, node_minus: NodeLike, control_plus: NodeLike, control_minus: NodeLike, model: str, **kwargs: Unpack[SwitchKwargs]) -> None: ...
    model: str
    initial_state: Optional[str]
class CurrentControlledSwitch(DipoleElement):
    def __init__(self, netlist: Netlist, name: Name, node_plus: NodeLike, node_minus: NodeLike, source: Any, model: str, **kwargs: Unpack[SwitchKwargs]) -> None: ...
    source: Any
    model: str
    initial_state: Optional[str]
class LosslessTransmissionLine(FixedPinElement):
    def __init__(self, netlist: Netlist, name: Name, input_plus: NodeLike, input_minus: NodeLike, output_plus: NodeLike, output_minus: NodeLike, impedance: Any, **kwargs: Unpack[TransmissionLineKwargs]) -> None: ...
class LossyTransmission(FixedPinElement): ...
class CoupledMulticonductorLine(NPinElement): ...
class UniformDistributedRCLine(FixedPinElement): ...
class SingleLossyTransmissionLine(FixedPinElement): ...
class SubCircuitElement(NPinElement):
    subcircuit_name: str
class XSpiceElement(NPinElement): ...
class GSSElement(NPinElement): ...
