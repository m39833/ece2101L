from os import PathLike
from pathlib import Path
from typing import Optional, Union

OSNAME: str
PLATFORM: str
INSTALLATION_PATH: Path
def get_os_name() -> str: ...
def get_spice_examples_path() -> Path: ...
