from typing import Any, Optional
from matplotlib.axes import Axes
from .WaveForm import WaveForm

def plot(waveform: WaveForm, axis: Optional[Axes] = ..., **kwargs: Any) -> Axes: ...
