from enum import Enum
from typing import Iterable, Mapping, Type

def EnumFactory(name: str, values: object) -> Type[Enum]: ...
