from typing import Any
from .Unit import PrefixedUnit, UnitValue, UnitValues, UnitValueShortcut

u_m: UnitValueShortcut
u_mm: UnitValueShortcut
u_um: UnitValueShortcut
u_μm: UnitValueShortcut
u_s: UnitValueShortcut
u_ms: UnitValueShortcut
u_us: UnitValueShortcut
u_μs: UnitValueShortcut
u_ns: UnitValueShortcut
u_ps: UnitValueShortcut
u_Hz: UnitValueShortcut
u_kHz: UnitValueShortcut
u_MHz: UnitValueShortcut
u_GHz: UnitValueShortcut
u_A: UnitValueShortcut
u_mA: UnitValueShortcut
u_uA: UnitValueShortcut
u_μA: UnitValueShortcut
u_nA: UnitValueShortcut
u_pA: UnitValueShortcut
u_V: UnitValueShortcut
u_mV: UnitValueShortcut
u_uV: UnitValueShortcut
u_μV: UnitValueShortcut
u_nV: UnitValueShortcut
u_F: UnitValueShortcut
u_mF: UnitValueShortcut
u_uF: UnitValueShortcut
u_μF: UnitValueShortcut
u_nF: UnitValueShortcut
u_pF: UnitValueShortcut
u_H: UnitValueShortcut
u_mH: UnitValueShortcut
u_uH: UnitValueShortcut
u_μH: UnitValueShortcut
u_nH: UnitValueShortcut
u_Ohm: UnitValueShortcut
u_kOhm: UnitValueShortcut
u_MOhm: UnitValueShortcut
u_Ω: UnitValueShortcut
u_kΩ: UnitValueShortcut
u_MΩ: UnitValueShortcut
u_S: UnitValueShortcut
u_W: UnitValueShortcut
u_mW: UnitValueShortcut
u_dB: UnitValueShortcut
u_Degree: UnitValueShortcut
u_Radian: UnitValueShortcut
u_Celsius: UnitValueShortcut

def kilo(value: Any) -> Any: ...
def mega(value: Any) -> Any: ...
def milli(value: Any) -> Any: ...
def micro(value: Any) -> Any: ...
def nano(value: Any) -> Any: ...
def pico(value: Any) -> Any: ...
