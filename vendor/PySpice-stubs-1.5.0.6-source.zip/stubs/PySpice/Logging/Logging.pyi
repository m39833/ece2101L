import logging
from os import PathLike
from typing import Any, Mapping, Optional, Union

def setup_logging(
    logging_config_file_name: Optional[Union[str, PathLike[str]]] = ...,
    application_name: Optional[str] = ...,
) -> logging.Logger: ...
def load_logging_config(logging_config_file_name: Union[str, PathLike[str]]) -> Mapping[str, Any]: ...
