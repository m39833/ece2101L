from typing import ClassVar

class Copper:
    atomic_number: ClassVar[int]
    atomic_mass: ClassVar[float]
    density: ClassVar[float]
    resistivity: ClassVar[float]
    temperature_coefficient: ClassVar[float]
