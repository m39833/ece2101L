import scipy.constants as constants

q: float
k: float
eps_0: float
mu_0: float
c: float
h: float
hbar: float
e: float
